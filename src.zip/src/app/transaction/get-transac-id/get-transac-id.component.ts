import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService, Transaction } from 'src/app/all.service';

@Component({
  selector: 'app-get-transac-id',
  templateUrl: './get-transac-id.component.html',
  styleUrls: ['./get-transac-id.component.css']
})
export class GetTransacIdComponent implements OnInit {
  transactionForm!: FormGroup;
  transactions: Transaction[] = [];
  message: string = '';
  messageType: string = '';
  customerId: number = 0;
  userAccounts: any[] = [];

  constructor(private service: AuthService) { }

  ngOnInit() {
    this.transactionForm = new FormGroup({
      accId: new FormControl('', [Validators.required])
    });
    const email = sessionStorage.getItem('userEmail');
    if (email) {
      this.service.getCustomerDetails(email).subscribe(data => {
        this.customerId = Number(data.custId);
        this.service.getAccountsByCustomerId(this.customerId).subscribe(accounts => {
          this.userAccounts = accounts.map(acc => acc.accountId);
        });
      });
    }

  }

  getTransactions() {
    const accId = Number(this.transactionForm.get('accId')?.value);
    if (!accId) {
      this.message = 'Please enter a valid account ID.';
      this.messageType = 'error';
      return;
    }
    if (!this.userAccounts.includes(accId)) {
      this.message = 'Enter your Account ID.';
      this.messageType = 'error';
      return;
    }
    this.service.getTransactionsByAccountId(accId).subscribe(
      response => {
        this.transactions = response.length > 0 ? response : [];
        this.message = response.length > 0 ? 'Transactions retrieved successfully.' : 'No transactions found.';
        this.messageType = response.length > 0 ? 'success' : 'error';
      },
      error => {
        this.message = 'Transactions Does not Exist';
        this.messageType = 'error';
        this.transactions = [];
      }
    );
  }
}
