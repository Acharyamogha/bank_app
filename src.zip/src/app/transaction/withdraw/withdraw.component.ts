import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  withdrawForm!: FormGroup;
  message: string = '';
  messageType: string = '';
  customerId: number = 0;
  userAccounts: any[] = [];


  constructor(private service: AuthService) { }

  ngOnInit() {
    this.withdrawForm = new FormGroup({
      accId: new FormControl(0, [Validators.required]),
      amount: new FormControl('', [Validators.required, Validators.min(500)])
    });
    const email = sessionStorage.getItem('userEmail');
    if (email) {
      this.service.getCustomerDetails(email).subscribe(data => {
        this.customerId = Number(data.custId);
        this.service.getAccountsByCustomerId(this.customerId).subscribe(accounts => {
          this.userAccounts = accounts.map(acc => acc.accountId);
        });
      });
    }
  }

  withdraw() {
    if (this.withdrawForm.valid) {
      const withdrawData = this.withdrawForm.value;
      if (!this.userAccounts.includes(Number(withdrawData.accId))) {
        this.message = 'Transaction failed: You can only withdraw from your own account.';
        this.messageType = 'error';
        return;
      }
      this.service.withdraw(withdrawData.amount, withdrawData.accId).subscribe(
        response => {
          this.message = response.message;
          this.messageType = response.status === 'success' ? 'success' : 'error';
        },
        error => {
          this.message = 'Deposit failed. Please try again.';
          this.messageType = 'error';
        }
      );
    } else {
      this.message = 'Please enter a valid amount and account ID.';
      this.messageType = 'error';
    }
  }
}
