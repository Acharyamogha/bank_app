import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetTransacIdDateComponent } from './get-transac-id-date.component';

describe('GetTransacIdDateComponent', () => {
  let component: GetTransacIdDateComponent;
  let fixture: ComponentFixture<GetTransacIdDateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetTransacIdDateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetTransacIdDateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
