import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService, Transaction } from 'src/app/all.service';

@Component({
  selector: 'app-get-transac-id-date',
  templateUrl: './get-transac-id-date.component.html',
  styleUrls: ['./get-transac-id-date.component.css']
})
export class GetTransacIdDateComponent {
  transactionForm!: FormGroup;
  transactions: Transaction[] = [];
  message: string = '';
  messageType: string = '';
  customerId: number = 0;
  userAccounts: number[] = [];

  constructor(private service: AuthService) { }

  ngOnInit() {
    this.transactionForm = new FormGroup({
      accId: new FormControl('', [Validators.required]),
      startDate: new FormControl('', [Validators.required]),
      endDate: new FormControl('', [Validators.required])
    });

    const email = sessionStorage.getItem('userEmail');
    if (email) {
      this.service.getCustomerDetails(email).subscribe(data => {
        this.customerId = Number(data.custId);
        this.service.getAccountsByCustomerId(this.customerId).subscribe(accounts => {
          this.userAccounts = accounts.map(acc => acc.accountId);
        });
      });
    }
  }
  getTransactions() {
    const accId = Number(this.transactionForm.get('accId')?.value);
    const startDate = this.transactionForm.get('startDate')?.value;
    const endDate = this.transactionForm.get('endDate')?.value;
    const today = new Date().toISOString().split('T')[0];

    console.log('Selected Account ID:', accId);
    console.log('Start Date:', startDate);
    console.log('End Date:', endDate);
    console.log('Today:', today);

    if (!accId || !startDate || !endDate) {
      this.message = 'Please enter valid account ID and date range.';
      this.messageType = 'error';
      return;
    }

    if (!this.userAccounts.includes(accId)) {
      this.message = 'Enter your Account ID.';
      this.messageType = 'error';
      return;
    }
    if (startDate > today) {
      this.message = 'Start date cannot be in the future.';
      this.messageType = 'error';
      return;
    }

    if (endDate > today) {
      this.message = 'End date cannot be in the future.';
      this.messageType = 'error';
      return;
    }

    this.service.getTransactionsByAccountIdAndDateRange(accId, startDate, endDate).subscribe(
      response => {
        this.transactions = response;
        this.message = response.length > 0 ? 'Transactions retrieved successfully.' : 'No transactions found.';
        this.messageType = response.length > 0 ? 'success' : 'error';
      },
      error => {
        this.transactions = [];
        this.message = 'Transactions Does not Exist';
        this.messageType = 'error';
      }
    );
  }
}
