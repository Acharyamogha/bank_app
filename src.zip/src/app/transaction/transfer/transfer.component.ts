import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {
  transferForm!: FormGroup;
  message: string = '';
  messageType: string = '';
  customerId: number = 0;
  userAccounts: any[] = [];


  constructor(private service: AuthService) { }

  ngOnInit() {
    this.transferForm = new FormGroup({
      sourceAccId: new FormControl('', [Validators.required]),
      targetAccId: new FormControl('', [Validators.required]),
      amount: new FormControl('', [Validators.required, Validators.min(500)])
    });
    const email = sessionStorage.getItem('userEmail');
    if (email) {
      this.service.getCustomerDetails(email).subscribe(data => {
        this.customerId = Number(data.custId);
        this.service.getAccountsByCustomerId(this.customerId).subscribe(accounts => {
          this.userAccounts = accounts.map(acc => acc.accountId);
        });
      });
    }
  }

  transfer() {
    if (this.transferForm.valid) {
      const transferData = this.transferForm.value;
      if (!this.userAccounts.includes(Number(transferData.sourceAccId))) {
        this.message = 'Transaction failed: You can only transfer from your own account.';
        this.messageType = 'error';
        return;
      }
      this.service.transfer(transferData.sourceAccId, transferData.targetAccId, transferData.amount).subscribe(
        response => {
          this.message = response.message;
          this.messageType = response.status === 'success' ? 'success' : 'error';
        },
        error => {
          this.message = 'Transfer failed. Please try again.';
          this.messageType = 'error';
        }
      );
    } else {
      this.message = 'Please enter valid account IDs and amount.';
      this.messageType = 'error';
    }
  }
}