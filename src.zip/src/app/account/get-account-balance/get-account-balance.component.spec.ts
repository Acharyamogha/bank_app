import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAccountBalanceComponent } from './get-account-balance.component';

describe('GetAccountBalanceComponent', () => {
  let component: GetAccountBalanceComponent;
  let fixture: ComponentFixture<GetAccountBalanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetAccountBalanceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetAccountBalanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
