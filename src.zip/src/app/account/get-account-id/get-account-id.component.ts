import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-get-account-id',
  templateUrl: './get-account-id.component.html',
  styleUrls: ['./get-account-id.component.css']
})
export class GetAccountIdComponent implements OnInit {
  accountId: number = 0;
  account: any = {};
  message: string = '';
  errorMessage: string = '';
  customerId: number = 0;
  userAccounts: number[] = [];

  constructor(private accountService: AuthService) { }
  ngOnInit(): void {
    const email = sessionStorage.getItem('userEmail');
    if (email) {
      this.accountService.getCustomerDetails(email).subscribe(data => {
        this.customerId = Number(data.custId);
        this.accountService.getAccountsByCustomerId(this.customerId).subscribe(accounts => {
          this.userAccounts = accounts.map(acc => acc.accountId);
        });
      });
    }
  }
  getAccountById(): void {
    if (this.accountId) {
      this.accountService.getAccountById(this.accountId).subscribe(
        (response) => {
          this.account = response;
          this.message = 'Account fetched successfully';
          this.errorMessage = '';
        },
        (error) => {
          this.account = {}
          this.errorMessage = 'Account Not Found';
          this.message = '';
        }
      );
    } else {
      this.errorMessage = 'Please enter a valid Account ID';
      this.message = '';
    }
  }
}
