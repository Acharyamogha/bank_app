import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-get-account',
  templateUrl: './get-account.component.html',
  styleUrls: ['./get-account.component.css']
})
export class GetAccountComponent implements OnInit {
  accounts: any[] = [];

  constructor(private accountService: AuthService) { }

  ngOnInit(): void {
    this.getAllAccounts();
  }

  getAllAccounts(): void {
    this.accountService.getAccounts().subscribe({
      next: (data) => this.accounts = data,
      error: (err) => console.error('Error fetching accounts:', err)
    });
  }
}

