import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetCustomerByAccountComponent } from './get-customer-by-account.component';

describe('GetCustomerByAccountComponent', () => {
  let component: GetCustomerByAccountComponent;
  let fixture: ComponentFixture<GetCustomerByAccountComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetCustomerByAccountComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetCustomerByAccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
