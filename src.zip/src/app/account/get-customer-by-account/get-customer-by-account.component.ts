import { Component } from '@angular/core';

@Component({
  selector: 'app-get-customer-by-account',
  templateUrl: './get-customer-by-account.component.html',
  styleUrls: ['./get-customer-by-account.component.css']
})
export class GetCustomerByAccountComponent {

}
