import { Component } from '@angular/core';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-verify-account',
  templateUrl: './verify-account.component.html',
  styleUrls: ['./verify-account.component.css']
})
export class VerifyAccountComponent {
  accountId: number = 0;
  message: string = '';
  errorMessage: string = '';

  constructor(private accountService: AuthService) { }

  verifyAccountExists(): void {
    this.accountService.verifyAccountExists(this.accountId).subscribe(
      (response) => {
        this.message = response.message;
      },
      (error) => {
        this.errorMessage = 'Error: ' + error.message;
        this.message = '';
      }
    );
  }
}
