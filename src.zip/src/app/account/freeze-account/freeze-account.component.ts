import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-freeze-account',
  templateUrl: './freeze-account.component.html',
  styleUrls: ['./freeze-account.component.css']
})
export class FreezeAccountComponent implements OnInit {
  accounts: any[] = [];
  message: string = '';
  errorMessage: string = '';

  constructor(private accountService: AuthService) { }

  ngOnInit(): void {
    this.getAllAccounts();
  }

  getAllAccounts(): void {
    this.accountService.getAccounts().subscribe({
      next: (data) => this.accounts = data.filter(account => account.freeze === false),
      error: (err) => console.error('Error fetching accounts:', err)
    });
  }

  freezeAccount(accountId: number): void {
    this.accountService.freezeAccount(accountId).subscribe(
      (response) => {
        this.message = response.message
        this.getAllAccounts();
      },
      (error) => {
        this.errorMessage = 'Error freezing account: ' + error.message;
      }
    );
  }

}
