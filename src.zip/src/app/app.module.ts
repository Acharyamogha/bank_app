import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { UserDashboardComponent } from './user/user-dashboard/user-dashboard.component';
import { HomeComponent } from './home/home.component';
import { GetAccountComponent } from './account/get-account/get-account.component';
import { AddAccountComponent } from './account/add-account/add-account.component';
import { DeleteAccountComponent } from './account/delete-account/delete-account.component';
import { UpdateAccountComponent } from './account/update-account/update-account.component';
import { GetAccountBalanceComponent } from './account/get-account-balance/get-account-balance.component';
import { VerifyAccountComponent } from './account/verify-account/verify-account.component';
import { FreezeAccountComponent } from './account/freeze-account/freeze-account.component';
import { UnfreezeAccountComponent } from './account/unfreeze-account/unfreeze-account.component';
import { GetAccountByCustomerComponent } from './account/get-account-by-customer/get-account-by-customer.component';
import { GetCustomerByAccountComponent } from './account/get-customer-by-account/get-customer-by-account.component';
import { GetAccountIdComponent } from './account/get-account-id/get-account-id.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
import { CustomerAddComponent } from './customer/customer-add/customer-add.component';
import { CustomerDeleteComponent } from './customer/customer-delete/customer-delete.component';
import { CustomerUpdateAddressComponent } from './customer/customer-update-address/customer-update-address.component';
import { CustomerUpdateNameComponent } from './customer/customer-update-name/customer-update-name.component';
import { CustomerDetailsComponent } from './customer/customer-details/customer-details.component';
import { CustomerListComponent } from './customer/customer-list/customer-list.component';
import { CustomerUpdateDtoComponent } from './customer/customer-update-dto/customer-update-dto.component';
import { DepositComponent } from './transaction/deposit/deposit.component';
import { WithdrawComponent } from './transaction/withdraw/withdraw.component';
import { TransferComponent } from './transaction/transfer/transfer.component';
import { GetTransacIdComponent } from './transaction/get-transac-id/get-transac-id.component';
import { GetTransacIdDateComponent } from './transaction/get-transac-id-date/get-transac-id-date.component';
import { GetAllTransacComponent } from './transaction/get-all-transac/get-all-transac.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    AdminDashboardComponent,
    UserDashboardComponent,
    HomeComponent,
    GetAccountComponent,
    AddAccountComponent,
    DeleteAccountComponent,
    UpdateAccountComponent,
    GetAccountBalanceComponent,
    VerifyAccountComponent,
    FreezeAccountComponent,
    UnfreezeAccountComponent,
    GetAccountByCustomerComponent,
    GetCustomerByAccountComponent,
    GetAccountIdComponent,
    UnauthorizedComponent,
    CustomerAddComponent,
    CustomerDeleteComponent,
    CustomerUpdateAddressComponent,
    CustomerUpdateNameComponent,
    CustomerDetailsComponent,
    CustomerListComponent,
    CustomerUpdateDtoComponent,
    DepositComponent,
    WithdrawComponent,
    TransferComponent,
    GetTransacIdComponent,
    GetTransacIdDateComponent,
    GetAllTransacComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
