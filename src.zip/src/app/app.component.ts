import { Component, OnInit } from '@angular/core';
import { AuthService } from './all.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'BankApp';
  customerData: any = {};
  showProfile = false;
  userProfilePic: string = 'assets/profile.png';

  constructor(private service: AuthService, private router: Router) { }

  logout() {
    this.service.logout();
    this.showProfile = false;
    this.customerData = {};
    sessionStorage.clear();
    this.router.navigate(['/login']);
  }

  isAuthenticated(): boolean {
    return sessionStorage.getItem('isAuthenticated') === 'true';
  }
  ngOnInit() {
    const serverRestarted = !localStorage.getItem('sessionActive');

    if (serverRestarted) {
      sessionStorage.clear();
      localStorage.setItem('sessionActive', 'true');
      this.router.navigate(['/login']);
    }

    const email = sessionStorage.getItem('userEmail');
    if (email) {
      this.service.getCustomerDetails(email).subscribe(data => {
        this.customerData = data;
      });
    }
  }
  loadCustomerData() {
    const email = sessionStorage.getItem('userEmail');
    console.log('Fetching Customer Data on Profile Toggle');

    if (email && !this.customerData.custId) {
      this.service.getCustomerDetails(email).subscribe(data => {
        this.customerData = data;
      });
    }
  }
  toggleProfile() {
    this.loadCustomerData();
    this.showProfile = !this.showProfile;
  }
}
