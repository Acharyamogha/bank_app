import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-customer-update-address',
  templateUrl: './customer-update-address.component.html',
  styleUrls: ['./customer-update-address.component.css']
})
export class CustomerUpdateAddressComponent implements OnInit {
  customerForm!: FormGroup;
  message: string = '';
  errorMessage: string = '';

  constructor(private fb: FormBuilder, private authService: AuthService) { }


  ngOnInit(): void {
    this.customerForm = this.fb.group({
      custId: [{ value: '', disabled: true }], 
      address: this.fb.group({
        dNo: ['', Validators.required],
        streetName: ['', Validators.required],
        city: ['', Validators.required],
        state: ['', Validators.required],
        pincode: ['', [
          Validators.required,
          Validators.pattern('^[0-9]{6}$') 
        ]]
      })
    }, { updateOn: 'blur' });

    const email = sessionStorage.getItem('userEmail');

    if (email) {
      this.authService.getCustomerDetails(email).subscribe(data => {
        const customerId = Number(data.custId);
        this.customerForm.patchValue({ custId: customerId });
      });
    }
  }


  updateCustomerAddress(): void {
    const customerId = Number(this.customerForm.getRawValue().custId);
    if (this.customerForm.valid) {
      this.authService.updateCustomerAddress(
        customerId,
        this.customerForm.value.address
      ).subscribe(
        () => {
          this.message = `✅ Customer ID ${customerId} address updated successfully`;
          this.errorMessage = '';
        },
        error => {
          if (error.status === 404) {
            this.message = `Customer with ID ${this.customerForm.value.custId} not found.`;
            this.errorMessage = '';
          } else {
            this.message = '';
            this.errorMessage = error.error?.message || 'Failed to update customer address. Please try again later.';
          }
        }
      );
    } else {
      this.message = "Please fill out all required fields correctly.";
    }
  }
}
