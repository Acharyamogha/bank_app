import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerUpdateNameComponent } from './customer-update-name.component';

describe('CustomerUpdateNameComponent', () => {
  let component: CustomerUpdateNameComponent;
  let fixture: ComponentFixture<CustomerUpdateNameComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerUpdateNameComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerUpdateNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
