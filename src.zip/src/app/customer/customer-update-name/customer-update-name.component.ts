import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-customer-update-name',
  templateUrl: './customer-update-name.component.html',
  styleUrls: ['./customer-update-name.component.css']
})
export class CustomerUpdateNameComponent implements OnInit {
  customerForm!: FormGroup;
  message: string = '';
  errorMessage: string = '';

  constructor(private fb: FormBuilder, private authService: AuthService) { }

  ngOnInit(): void {
    this.customerForm = this.fb.group({
      custId: [{ value: '', disabled: true }],
      name: ['', Validators.required]
    });

    const email = sessionStorage.getItem('userEmail');

    if (email) {
      this.authService.getCustomerDetails(email).subscribe(data => {
        const customerId = Number(data.custId);
        this.customerForm.patchValue({ custId: customerId });
      });
    }

  }

  updateCustomerName(): void {
    const customerId = Number(this.customerForm.getRawValue().custId);
    console.log(customerId);
    if (this.customerForm.valid) {
      this.authService.updateCustomerName(
        customerId,
        this.customerForm.value.name
      ).subscribe(
        () => {
          this.message = ` Customer ID ${customerId} name updated successfully`;
          this.errorMessage = '';
          this.customerForm.patchValue({ name: '' });
        },
        error => {
          if (error.status === 404) {
            this.message = ` Customer with ID ${this.customerForm.value.custId} not found.`;
            this.errorMessage = '';
          } else {
            this.message = '';
            this.errorMessage = error.error?.message || ' Failed to update customer name. Please try again later.';
          }
        }
      );
    } else {
      this.message = " Please fill out the required fields correctly.";
    }
  }
}
