import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-customer-add',
  templateUrl: './customer-add.component.html',
  styleUrls: ['./customer-add.component.css']
})
export class CustomerAddComponent {
  customerForm: FormGroup;
  message: string = '';

  constructor(private fb: FormBuilder, private authService: AuthService) {
    this.customerForm = this.fb.group({
      fullName: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20)]],
      contactNo: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      addr: this.fb.group({
        dNo: ['', Validators.required],
        streetName: ['', Validators.required],
        city: ['', Validators.required],
        state: ['', Validators.required],
        pincode: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]]
      }),
      login: this.fb.group({
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(16)]],
        role: ['', Validators.required]
      })
    });
  }

  addCustomer(): void {
    if (this.customerForm.valid) {
      this.authService.addCustomer(this.customerForm.value).subscribe(
        response => this.message = "Customer added successfully",
        error => this.message = error.error?.message || "Failed to add customer"
      );
    } else {
      this.message = "Please fill out all required fields correctly.";
    }
  }
}
