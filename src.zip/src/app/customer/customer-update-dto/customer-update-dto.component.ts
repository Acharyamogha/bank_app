import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-customer-update-dto',
  templateUrl: './customer-update-dto.component.html',
  styleUrls: ['./customer-update-dto.component.css']
})
export class CustomerUpdateDtoComponent implements OnInit {
  customerForm!: FormGroup;
  message: string = '';
  errorMessage: string = '';

  constructor(private fb: FormBuilder, private authService: AuthService) {
  }

  ngOnInit(): void {
    this.customerForm = this.fb.group({
      custId: [{ value: '', disabled: true }],
      customer: this.fb.group({
        fullName: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20)]],
        contactNo: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]]
      })
    });

    const email = sessionStorage.getItem('userEmail');

    if (email) {
      this.authService.getCustomerDetails(email).subscribe(data => {
        const customerId = Number(data.custId);
        this.customerForm.patchValue({ custId: customerId });
      });
    }
  }

  updateCustomer(): void {
    const customerId = Number(this.customerForm.getRawValue().custId);
    if (this.customerForm.valid) {
      this.authService.updateCustomer(
        customerId,
        this.customerForm.value.customer
      ).subscribe(
        () => {
          this.message = `Customer ID ${customerId} updated successfully`,
            this.customerForm.reset();
        },
        error => this.errorMessage = error.error?.message || 'Failed to update customer. Please try again later.'
      );
    } else {
      this.message = "Please fill out all required fields correctly.";
    }
  }
}
