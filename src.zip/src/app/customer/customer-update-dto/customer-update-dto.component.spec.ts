import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerUpdateDtoComponent } from './customer-update-dto.component';

describe('CustomerUpdateDtoComponent', () => {
  let component: CustomerUpdateDtoComponent;
  let fixture: ComponentFixture<CustomerUpdateDtoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerUpdateDtoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerUpdateDtoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
