import { Component } from '@angular/core';
import { AuthService } from 'src/app/all.service';


@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent {
  customerId!: number;
  customer: any;
  errorMessage: string = '';
  message: string = '';

  constructor(private authService: AuthService) { }

  getCustomerById(): void {
    this.errorMessage = '';
    this.message = '';
    this.customer = null;

    if (!this.customerId) {
      this.errorMessage = 'Please enter a valid Customer ID.';
      return;
    }

    this.authService.getCustomerById(this.customerId).subscribe({
      next: (data) => {
        this.customer = data;
        this.message = 'Customer details fetched successfully.';
      },
      error: (err) => {
        this.errorMessage = err.error?.message || 'Customer Does not exist with ID ' + this.customerId;
      }
    });
  }
}
