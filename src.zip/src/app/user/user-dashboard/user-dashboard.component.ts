import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {
  userName: string = 'User';
  userProfilePic: string = 'assets/profile.png';

  constructor(private authService: AuthService) { }

  ngOnInit() {
    this.fetchUserProfile();
  }

  fetchUserProfile() {
    const email = sessionStorage.getItem('userEmail');
    if (email) {
      this.authService.getCustomerDetails(email).subscribe(data => {
        this.userName = data.fullName;

      }, error => {
        console.error("Error fetching user profile:", error);
      });
    }
  }
}
