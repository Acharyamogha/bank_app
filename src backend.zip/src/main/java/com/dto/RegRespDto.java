package com.dto;

public class RegRespDto {
	
	private long custId;
	private String email;
	private String message;
	
	public RegRespDto() {
		// TODO Auto-generated constructor stub
	}

	public long getCustId() {
		return custId;
	}

	public void setCustId(long custId) {
		this.custId = custId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
}
