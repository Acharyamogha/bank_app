package com.dto;

public class CustDto {
	private long custId;
	private String name;
	private String contactNo;
	private String role;
	
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public CustDto() {
		// TODO Auto-generated constructor stub
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public long getCustId() {
		return custId;
	}

	public void setCustId(long custId) {
		this.custId = custId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	@Override
	public String toString() {
		return "CustDto [custId=" + custId + ", name=" + name + ", email=" + "]";
	}
	
}
