package com.dto;

import java.time.LocalDateTime;

	public class TransactionDto {
	private Long tranId;
	private double amount;
	private Long accountId;
	private Long receiverAccNo;
	private Long senderAccNo;
	private String status;
	private LocalDateTime timeStamp;
	private String transType;
	private Long custId;
	
	public TransactionDto() {
		// TODO Auto-generated constructor stub
	}
	public TransactionDto(Long tranId, double amount,Long custId, Long accountId, Long receiverAccNo, Long senderAccNo, String status,
			LocalDateTime timeStamp, String transType) {
		super();
		this.tranId=tranId;
		this.amount = amount;
		this.accountId = accountId;
		this.receiverAccNo = receiverAccNo;
		this.senderAccNo = senderAccNo;
		this.status = status;
		this.timeStamp = timeStamp;
		this.transType = transType;
		this.custId = custId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Long getAccountId() {
		return accountId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	public long getReceiverAccNo() {
		return receiverAccNo;
	}
	public void setReceiverAccNo(Long receiverAccNo) {
		this.receiverAccNo = receiverAccNo;
	}
	public Long getSenderAccNo() {
		return senderAccNo;
	}
	public void setSenderAccNo(Long senderAccNo) {
		this.senderAccNo = senderAccNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public LocalDateTime getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(LocalDateTime timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public Long getCustId() {
		return custId;
	}
	public void setCustId(Long custId) {
		this.custId = custId;
	}
	public Long getTranId() {
		return tranId;
	}
	public void setTranId(Long tranId) {
		this.tranId = tranId;
	}
	
	
}
