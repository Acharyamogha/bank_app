package com.dto;

import java.time.LocalDate;

public class AccountDto {
	private Long accountId;
	private String accType;
	private long customerId;
	private double balance;
	private LocalDate createdAt;
	private boolean isFreeze;
	
	public AccountDto() {
		// TODO Auto-generated constructor stub
	}

	public AccountDto(Long accountId, String accType, long customerId, double balance, LocalDate createdAt, boolean isFreeze) {
		super();
		this.accountId = accountId;
		this.accType = accType;
		this.customerId = customerId;
		this.balance = balance;
		this.createdAt = createdAt;
		this.isFreeze = isFreeze;
	}

	public Long getAccountId() {
		return accountId;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public LocalDate getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDate createdAt) {
		this.createdAt = createdAt;
	}

	public boolean isFreeze() {
		return isFreeze;
	}

	public void setisFreeze(boolean isFreeze) {
		this.isFreeze = isFreeze;
	}
	
}
