	package com.service;
 
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dto.AccountDto;
import com.dto.CustDto;
import com.entity.Account;
import com.entity.Customer;
import com.entity.Transaction;
import com.exception.AccountNotFoundException;
import com.exception.CustomerNotFoundException;
import com.repository.AccountRepo;
import com.repository.CustomerRepo;

import jakarta.transaction.Transactional;
 
@Service
public class AccountServiceImpl implements AccountService{
 
	@Autowired
	private AccountRepo accRepo;
	@Autowired
	private CustomerRepo custRepo;
	
	@Transactional
	@Override
	public Account addAccount(Account account) {
		long custId=account.getCustomerId();
		Customer cust=custRepo.getById(custId);
		account.setCustomer(cust);
		return accRepo.save(account);
	}
    
	@Transactional
	@Override
	public AccountDto getAccountDetailsById(long accId) throws AccountNotFoundException{
		Account a=accRepo.findById(accId).orElseThrow(() -> new AccountNotFoundException("No Account Exists with the ID " + accId));
		AccountDto adto= new AccountDto();
		adto.setAccountId(a.getAccId());
		adto.setAccType(a.getAccType());
		adto.setBalance(a.getBalance());
		adto.setCreatedAt(a.getCreatedAt());
		adto.setCustomerId(a.getCustomerId());
		adto.setisFreeze(a.getisFreeze());
		
		return adto;
	}
 
	@Transactional
	@Override
	public List<AccountDto> getAllAccounts() {
		List<Account> alist= accRepo.findAll();
		List<AccountDto> accDto=new ArrayList<>();
		for(Account a:alist) {
			AccountDto adto= new AccountDto();
			adto.setAccountId(a.getAccId());
			adto.setAccType(a.getAccType());
			adto.setBalance(a.getBalance());
			adto.setCreatedAt(a.getCreatedAt());
			adto.setCustomerId(a.getCustomerId());
			adto.setisFreeze(a.getisFreeze());
			accDto.add(adto);
		}
		return accDto;
	}
    
	@Transactional
	@Override
	public List<AccountDto> findByCustId(long CustId) {
		List<Account> alist= accRepo.findByCustomerCustId(CustId);
		List<AccountDto> accDto=new ArrayList<>();
		for(Account a:alist) {
			AccountDto adto= new AccountDto();
			adto.setAccountId(a.getAccId());
			adto.setAccType(a.getAccType());
			adto.setBalance(a.getBalance());
			adto.setCreatedAt(a.getCreatedAt());
			adto.setCustomerId(a.getCustomerId());
			adto.setisFreeze(a.getisFreeze());
			accDto.add(adto);
		}
		return accDto;
	}
	
	@Transactional
	@Override
	public Account updateAccount(Account account) throws AccountNotFoundException{
		long custId=account.getCustomerId();
		Customer cust=custRepo.getById(custId);
		Account acc=accRepo.findById(account.getAccId()).orElseThrow(() -> new AccountNotFoundException("No Account Exists with the ID " + account.getAccId()));
		acc.setAccType(account.getAccType());
		acc.setBalance(account.getBalance());
		acc.setCreatedAt(account.getCreatedAt().toString());
		acc.setCustomer(cust);
		return accRepo.save(acc);
	}
 
	@Transactional
	@Override
	public void deleteAccount(long accId) throws AccountNotFoundException{
		Account acc= accRepo.findById(accId).orElseThrow(() -> new AccountNotFoundException("No Account Exists with the ID " + accId));
		accRepo.deleteById(accId);
		
	}
 
	@Transactional
	@Override
	public double getAccountBalanceById(Long accId) throws AccountNotFoundException{
		Account acc=accRepo.findById(accId).orElseThrow(() -> new AccountNotFoundException("No Account Exists with the ID " + accId));
		double balance= acc.getBalance();
		return balance;
	}
 
	@Transactional
	@Override
	public boolean verifyAccountExists(long accId) {
		return accRepo.existsById(accId);
	}
 
	@Transactional
	@Override
	public int freezeAccount(long accId)throws AccountNotFoundException {
		Account acc= accRepo.findById(accId).orElseThrow(() -> new AccountNotFoundException("No Account Exists with the ID " + accId));
		return accRepo.freezeAccount(accId);
	
	}
 
	@Transactional
	@Override
	public int unFreezeAccount(long accId) throws AccountNotFoundException{
		Account acc= accRepo.findById(accId).orElseThrow(() -> new AccountNotFoundException("No Account Exists with the ID " + accId));
		return accRepo.unFreezeAccount(accId);
	
	}
 
	@Transactional
	@Override
	public Customer getCustomerDetails(long accId) throws AccountNotFoundException{
		Account acc= accRepo.findById(accId).orElseThrow(() -> new AccountNotFoundException("No Account Exists with the ID " + accId));
		return accRepo.getCustomerDetails(accId);
	}

	@Override
	public List<Transaction> findTransactionsByAccIdAndDateRange(long accId, LocalDateTime startDate, LocalDateTime endDate) throws AccountNotFoundException{
		Account acc= accRepo.findById(accId).orElseThrow(() -> new AccountNotFoundException("No Account Exists with the ID " + accId));
		return accRepo.findTransactionsByAccIdAndDateRange(accId, startDate, endDate);
	}
	
 
}