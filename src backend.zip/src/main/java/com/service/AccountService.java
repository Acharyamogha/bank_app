package com.service;
 
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.dto.AccountDto;
import com.entity.Account;
import com.entity.Customer;
import com.entity.Transaction;
import com.exception.AccountNotFoundException;
import com.exception.CustomerFoundException;
 
public interface AccountService {
	Account addAccount(Account account);
	AccountDto getAccountDetailsById(long accId) throws AccountNotFoundException;
	List<AccountDto> getAllAccounts();
	List<AccountDto> findByCustId(long CustId);
	Account updateAccount(Account account)throws AccountNotFoundException;
	void deleteAccount(long accID)throws AccountNotFoundException;
	double getAccountBalanceById(Long accId)throws AccountNotFoundException;
	boolean verifyAccountExists(long accId);
	int freezeAccount(long accId)throws AccountNotFoundException;
	int unFreezeAccount(long accId)throws AccountNotFoundException;
	Customer getCustomerDetails(long accId)throws AccountNotFoundException;
	List<Transaction> findTransactionsByAccIdAndDateRange(long accId, LocalDateTime startDate, LocalDateTime endDate)throws AccountNotFoundException;
 
}