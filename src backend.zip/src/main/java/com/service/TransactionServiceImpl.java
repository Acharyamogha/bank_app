package com.service;
 
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dto.TransactionDto;
import com.entity.Account;
import com.entity.Transaction;
import com.repository.AccountRepo;
import com.repository.TransactionRepo;

import jakarta.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class TransactionServiceImpl implements TransactionService {
	@Autowired
	 TransactionRepo transRepo;
	@Autowired
	 AccountRepo accRepo;
	
	@Transactional
	@Override
	public Map<String, String> deposit(double amount, long accId) {
		Map<String, String> response = new HashMap<>();
		Optional<Account> acc=accRepo.findById(accId);
		if (acc.isEmpty()) {
			response.put("status", "error");
	        response.put("message", "Deposit failed: Account ID " + accId + " does not exist.");
	        return response;  
	    }
		Account account = acc.get();
		 if (account.getisFreeze()) {
			 Transaction trans = new Transaction();
			 trans.setSenderAccNo(accId);
			 trans.setAcc(account);
			 trans.setReceiverAccNo(accId);
			 trans.setAmount(amount);
			 trans.setTransType("Deposit");
			 trans.setTimeStamp(LocalDateTime.now());
			 trans.setStatus("Failed");
			 transRepo.save(trans);
			 response.put("status", "error");
		        response.put("message", "Deposit failed: Account ID " + accId + " is frozen.");
		        return response;
		    }
		 account.setBalance(account.getBalance() + amount);
		
		 Transaction trans = new Transaction();
		 trans.setAcc(account);
		 trans.setSenderAccNo(accId);
		 trans.setReceiverAccNo(accId);
		 trans.setAmount(amount);
		 trans.setTransType("Deposit");
		 trans.setTimeStamp(LocalDateTime.now());
		 trans.setStatus("Successful");
	
		 transRepo.save(trans);
		 accRepo.save(account);
		
		 response.put("status", "success");
		    response.put("message", "Deposit of " + amount + " to Account ID " + accId + " was successful. Total Balance is " + account.getBalance());
		    return response;
	}
	
	@Transactional
	@Override
	public Map<String, String> withdraw(double amount, long accId) {
		Optional<Account> acc=accRepo.findById(accId);
		Map<String, String> response = new HashMap<>();
		if (acc.isEmpty()) {
			response.put("status", "error");
	        response.put("message", "Withdraw failed: Account ID " + accId + " does not exist.");
	        return response;  
	    }
		Account account = acc.get();
		 if (account.getisFreeze()) {
			 Transaction trans = new Transaction();
			 trans.setAcc(account);
			 trans.setSenderAccNo(accId);
			 trans.setReceiverAccNo(accId);
			 trans.setAmount(amount);
			 trans.setTransType("Withdraw");
			 trans.setTimeStamp(LocalDateTime.now());
			 trans.setStatus("Failed");
			 transRepo.save(trans);
			 response.put("status", "error");
		        response.put("message", "Withdraw failed: Account ID " + accId + " is frozen.");
		        return response;
		    }
		 if(account.getBalance()<amount) {
			 response.put("status", "error");
		        response.put("message", "Withdraw not possible. Amount exceeds balance");
		        return response;
		 }
		 account.setBalance(account.getBalance() - amount);
		
		 Transaction trans = new Transaction();
		 trans.setSenderAccNo(accId);
		 trans.setAcc(account);
		 trans.setReceiverAccNo(accId);
		 trans.setAmount(amount);
		 trans.setTransType("Withdraw");
		 trans.setTimeStamp(LocalDateTime.now());
		 trans.setStatus("Successful");
	
		 transRepo.save(trans);
		 accRepo.save(account);
		
		 response.put("status", "success");
		    response.put("message", "Withdraw of " + amount + " from Account ID " + accId + " was successful. Total Balance is " + account.getBalance());
		    return response;
	}
 
	@Override
	public Map<String, String> transferAmount(long sourceAccId, long targetAccId,double amount) {
		
		Optional<Account> srcacc=accRepo.findById(sourceAccId);
		Optional<Account> taracc=accRepo.findById(targetAccId);
		Map<String, String> response = new HashMap<>();
		if (srcacc.isEmpty()) {
			response.put("status", "error");
	        response.put("message", "Transfer failed: Account ID " + sourceAccId + " does not exist.");
	        return response;
	    }
		if (taracc.isEmpty()) {
			response.put("status", "error");
	        response.put("message", "Transfer failed: Account ID " + targetAccId + " does not exist.");
	        return response;
	    }
		
		Account sourceAcc=srcacc.get();
		Account targetAcc=taracc.get();
		
		if (sourceAcc.getisFreeze()) {
			Transaction trans = new Transaction();
			 trans.setAcc(sourceAcc);
			 trans.setSenderAccNo(sourceAccId);
			 trans.setReceiverAccNo(targetAccId);
			 trans.setAmount(amount);
			 trans.setTransType("Amount Transfer");
			 trans.setTimeStamp(LocalDateTime.now());
			 trans.setStatus("Failed: Source Account is Frozen");
			
			 transRepo.save(trans);
			 response.put("status", "error");
		        response.put("message", "Transfer failed: Source account ID " + sourceAccId + " is frozen.");
		        return response;
        }
		if (targetAcc.getisFreeze()) {
			Transaction trans = new Transaction();
			 trans.setAcc(targetAcc);
			 trans.setSenderAccNo(sourceAccId);
			 trans.setReceiverAccNo(targetAccId);
			 trans.setAmount(amount);
			 trans.setTransType("Amount Transfer");
			 trans.setTimeStamp(LocalDateTime.now());
			 trans.setStatus("Failed: Target Account is Frozen");
			
			 transRepo.save(trans);
			 response.put("status", "error");
		        response.put("message", "Transfer failed: Target account ID " + targetAccId + " is frozen.");
		        return response;
		 }
		
		if(sourceAcc.getBalance()<amount) {
			response.put("status", "error");
	        response.put("message", "Transfer failed: Amout Exceeds balance of Rs. "+sourceAcc.getBalance());
	        return response;
		 }
		
		 Transaction trans = new Transaction();
		 trans.setSenderAccNo(sourceAccId);
		 trans.setAcc(sourceAcc);
		 trans.setReceiverAccNo(targetAccId);
		 trans.setAmount(amount);
		 trans.setTransType("Amount Transfer Sent");
		 trans.setTimeStamp(LocalDateTime.now());
		 trans.setStatus("Successful");
		
		 transRepo.save(trans);
		 
		 Transaction tran = new Transaction();
		 tran.setSenderAccNo(sourceAccId);
		 tran.setAcc(targetAcc);
		 tran.setReceiverAccNo(targetAccId);
		 tran.setAmount(amount);
		 tran.setTransType("Amount Transfer Received");
		 tran.setTimeStamp(LocalDateTime.now());
		 tran.setStatus("Successful");
		
		 transRepo.save(tran);
		 sourceAcc.setBalance(sourceAcc.getBalance() - amount);
		 accRepo.save(sourceAcc);
		 targetAcc.setBalance(targetAcc.getBalance() + amount);
		 accRepo.save(targetAcc);
		
		 response.put("status", "success");
	        response.put("message", "Transfer of " + amount + " from account ID " + sourceAccId + " to account ID " + targetAccId + " was successful.");
	        return response;    
		 }
		
		
 
	@Override
	public List<TransactionDto> getTransactionsByAccountId(Long accId) {
		return transRepo.findAllTransactionsByAccountId(accId);
	}
 
	@Override
	public List<TransactionDto> getTransactionsByAccountIdAndDateRange(Long accId, LocalDateTime startDate, LocalDateTime endDate) {
		return transRepo.findTransactionsByAccountIdAndDateRange(accId, startDate, endDate);	
	}

	@Override
	public List<TransactionDto> getAllTransaction() {
		List<Transaction> tlist = new ArrayList<>();
		tlist=transRepo.findAll();
		List<TransactionDto> tdlist = new ArrayList<>();
		for(Transaction t:tlist) {
			TransactionDto tdto = new TransactionDto();
			tdto.setAccountId(t.getAcc().getAccId());
			tdto.setAmount(t.getAmount());
			tdto.setCustId(t.getAcc().getCustomerId());
			tdto.setReceiverAccNo(t.getReceiverAccNo());
			tdto.setSenderAccNo(t.getSenderAccNo());
			tdto.setStatus(t.getStatus());
			tdto.setTimeStamp(t.getTimeStamp());
			tdto.setTranId(t.getTranId());
			tdto.setTransType(t.getTransType());
			tdlist.add(tdto);
		}
		return tdlist;
	}

 
}