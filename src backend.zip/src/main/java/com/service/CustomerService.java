package com.service;

import java.util.List;

import com.dto.CustDto;
import com.dto.RegRespDto;
import com.dto.RegisterDto;
import com.entity.Address;
import com.entity.Customer;
import com.entity.Login;
import com.exception.CustomerFoundException;
import com.exception.CustomerNotFoundException;

public interface CustomerService {
	Customer addCustomer(Customer customer)throws CustomerFoundException;
	List<CustDto> getAllCustomers();
	Customer findCustomerById(long custId) throws CustomerNotFoundException;
	Customer updateCustomerById(long custId, Customer cust) throws CustomerNotFoundException;
	void deleteCustomer(long custId) throws CustomerNotFoundException;
	Customer updateCustomerName(long custId, String name) throws CustomerNotFoundException;
	Customer updateCustomerAddr(long custId, Address addr) throws CustomerNotFoundException;
	List<Customer> getCustomerByName(String name) throws CustomerNotFoundException;
	CustDto getCustDtoById(long custId) throws CustomerNotFoundException;
	CustDto updateCustDtoById(long custId, CustDto customer) throws CustomerNotFoundException;
	Customer findByLogin(Login login);
	Customer findByEmail(String email);
	
}
