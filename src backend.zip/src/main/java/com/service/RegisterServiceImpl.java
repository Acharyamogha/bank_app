package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dto.RegRespDto;
import com.dto.RegisterDto;
import com.entity.Address;
import com.entity.Customer;
import com.entity.Login;
import com.repository.CustomerRepo;
import com.repository.LoginRepo;

@Service
public class RegisterServiceImpl implements RegisterService {
	
	@Autowired
	CustomerRepo custRepo;
	@Autowired
	LoginRepo loginRepo;
	
	@Override
	public RegRespDto registerCust(RegisterDto customer) {
		
		if(!loginRepo.existsById(customer.getLogin().getEmail())) {
			Customer c = new Customer();
			c.setAddr(customer.getAddress());
			c.setContactNo(customer.getContactNo());
			c.setFullName(customer.getFullName());
			c.setLogin(customer.getLogin());
			custRepo.save(c);
			
			RegRespDto response=new RegRespDto();
			response.setCustId(c.getCustId());
			response.setEmail(c.getLogin().getEmail());
			response.setMessage("You are Registered successfully with Customer ID "+ response.getCustId()+" and email address "+response.getEmail());
			return response;
		}
			RegRespDto response=new RegRespDto();

			System.out.println(customer);
			Customer cust = custRepo.findByLogin(loginRepo.getById(customer.getLogin().getEmail()));
			response.setCustId(cust.getCustId());
			response.setEmail(cust.getLogin().getEmail());
			response.setMessage("Customer already Exists with the email address "+response.getEmail());
			return response;
		
		
	}

}
