package com.service;

import java.util.Map;
import java.util.Optional;

import com.entity.Login;

public interface LoginService {
	Map<String,String> loginUser(Login login);
	String getUserRole(String email);
}
