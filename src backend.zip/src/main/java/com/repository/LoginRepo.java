package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.entity.Login;

public interface LoginRepo extends JpaRepository<Login, String> {
	Login findByEmailAndPassword(String email, String password);
	String findByEmail(String email);
}
