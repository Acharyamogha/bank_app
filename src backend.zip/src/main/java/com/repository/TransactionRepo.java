package com.repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.dto.TransactionDto;
import com.entity.Transaction;
 
public interface TransactionRepo extends JpaRepository<Transaction,Long>{


@Query("SELECT new com.dto.TransactionDto(t.tranId, t.amount,t.acc.customer.custId, t.acc.accId, t.receiverAccNo, t.senderAccNo, t.status, t.timeStamp, t.transType) " +"FROM Transaction t WHERE t.acc.accId = :accId")
	List<TransactionDto> findAllTransactionsByAccountId(@Param("accId") Long accId);


@Query("SELECT new com.dto.TransactionDto(t.tranId, t.amount,t.acc.customer.custId, t.acc.accId, t.receiverAccNo, t.senderAccNo, t.status, t.timeStamp, t.transType) " +"FROM Transaction t WHERE t.acc.accId = :accId AND t.timeStamp BETWEEN :startDate AND :endDate")
	List<TransactionDto> findTransactionsByAccountIdAndDateRange(@Param("accId") Long accId, @Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);



}