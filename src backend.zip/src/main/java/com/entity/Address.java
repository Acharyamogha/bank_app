package com.entity;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
public class Address {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long addrId;
	
	@NotBlank(message="Door Number Cannot be Blank")
	private String dNo;
	
	@NotBlank(message="Street Name Cannot be Blank")
	private String streetName;
	
	@NotBlank(message="City Cannot be Blank")
	private String city;
	
	@NotBlank(message="State Cannot be Blank")
	private String state;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="custId")
	@Valid
	private Customer customer;
	
	@NotNull(message="Account Type Cannot be Blank")
	private int pincode;
	
	public Address() {
		// TODO Auto-generated constructor stub
	}

	public long getAddrId() {
		return addrId;
	}

	public void setAddrId(long addrId) {
		this.addrId = addrId;
	}

	public String getdNo() {
		return dNo;
	}

	public void setdNo(String dNo) {
		this.dNo = dNo;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	
	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Address [addrId=" + addrId + ", dNo=" + dNo + ", streetName=" + streetName + ", city=" + city
				+ ", state=" + state + ", pincode=" + pincode + "]";
	}
	
	
}
