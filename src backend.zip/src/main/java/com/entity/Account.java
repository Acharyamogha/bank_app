package com.entity;
 
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long accId;
	
	@NotBlank(message="Account Type Cannot be Blank")
	private String accType;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="custID", nullable=true)
	@Valid
	private Customer customer;
	
	private long customerId;
	
	@Min(value = 500, message = "Amount must be greater than or equal to 500")
	private double balance;
	
	@OneToMany(cascade = CascadeType.ALL,mappedBy="acc")
	@Valid
	private List<Transaction> transac;
	
	private LocalDate createdAt;
	
	private boolean isFreeze=false;
	
	public Account() {
		// TODO Auto-generated constructor stub
	}
	
	
	public long getCustomerId() {
		return customerId;
	}


	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}


	public boolean getisFreeze() {
		return isFreeze;
	}
 
	public void setFreeze(boolean isFreeze) {
		this.isFreeze = isFreeze;
	}
 
	public long getAccId() {
		return accId;
	}
 
	public void setAccId(long accId) {
		this.accId = accId;
	}
 
	public String getAccType() {
		return accType;
	}
 
	public void setAccType(String accType) {
		this.accType = accType;
	}
 
	public Customer getCustomer() {
		return customer;
	}
 
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
 
	public double getBalance() {
		return balance;
	}
 
	public void setBalance(double balance) {
		this.balance = balance;
	}
 
 
 
	public List<Transaction> getTransac() {
		return transac;
	}
 
	public void setTransac(List<Transaction> transac) {
		this.transac = transac;
	}
 
	public LocalDate getCreatedAt() {
		return createdAt;
	}
 
	public void setCreatedAt(String createdAt) {
		this.createdAt = LocalDate.parse(createdAt);
	}
 
	@Override
	public String toString() {
		return "Account [accID=" + accId + ", accType=" + accType + ", customer=" + customer + ", balance=" + balance
				+ ", transac=" + transac + ", createdAt=" + createdAt + "]";
	}
 
}