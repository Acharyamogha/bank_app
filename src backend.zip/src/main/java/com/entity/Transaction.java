package com.entity;

import java.io.Serializable;
import java.time.LocalDateTime;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

@Entity
public class Transaction implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long tranId;
	
	@NotNull(message="Sender Account Number cannot be Null")
	private long senderAccNo;
	
	@NotNull(message="Receiver Account Number cannot be Null")
	private long receiverAccNo;
	
	@Min(value = 500, message = "Amount must be greater than or equal to 500")
    @Max(value = 100000, message = "Amount must be less than or equal to 100000")
	private double amount;
	
	private String transType;
	
	private LocalDateTime timeStamp;
	
	private String status;
	
	@ManyToOne
	@JoinColumn(name="accountId", nullable=false)
	private Account acc;
	
	public Transaction() {
		// TODO Auto-generated constructor stub
	}

	public Account getAcc() {
		return acc;
	}

	public void setAcc(Account acc) {
		this.acc = acc;
	}
	
	public long getTranId() {
		return tranId;
	}

	public void setTranId(long tranId) {
		this.tranId = tranId;
	}

	

	public long getSenderAccNo() {
		return senderAccNo;
	}

	public void setSenderAccNo(long senderAccNo) {
		this.senderAccNo = senderAccNo;
	}

	public long getReceiverAccNo() {
		return receiverAccNo;
	}

	public void setReceiverAccNo(long receiverAccNo) {
		this.receiverAccNo = receiverAccNo;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public LocalDateTime getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(LocalDateTime timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Transaction [tranID=" + tranId + ", senderAccNo=" + senderAccNo + ", receiverAccNo=" + receiverAccNo
				+ ", amount=" + amount + ", transType=" + transType + ", timeStamp=" + timeStamp + ", status=" + status
				+ "]";
	}
	

}
