package com.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
public class Login {
	@Id
	@Email(message="Enter a valid email")
	private String email;
	
	@Size(min=8, max=16, message="Password must be  between 8 to 16 characters")
	private String password;
	
	@NotBlank(message="Role Cannot be Blank")
	private String role;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="custId")
	private Customer customer;
	
	public Login() {
		// TODO Auto-generated constructor stub
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "Login [email=" + email + ", password=" + password + ", role=" + role + ", customer=" + customer + "]";
	}
	
}
