package com.entity;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;


@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long custId;
	
	@Size(min=3, max=20, message="Name must be between 3 to 20 characters")
	private String fullName;
	
	@Size(min=10, max=10, message="Enter a 10 digit contact number")
	private String contactNo;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="addId")
	@Valid
	private  Address addr;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="email")
	@Valid
	private Login login;
	
	@OneToMany(mappedBy = "customer", cascade = CascadeType.REMOVE, orphanRemoval = true)
    private List<Account> accounts;
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public long getCustId() {
		return custId;
	}

	public void setCustId(long custId) {
		this.custId = custId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public Address getAddr() {
		return addr;
	}

	
	public void setAddr(Address addr) {
		this.addr = addr;
	}

	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", fullName=" + fullName + ", contactNo=" + contactNo + ", addr=" + addr
				+ ", login=" + login + "]";
	}
	
	
}
