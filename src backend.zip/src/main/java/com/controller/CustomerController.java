package com.controller;

import java.util.List;

import org.hibernate.Hibernate;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dto.CustDto;
import com.entity.Address;
import com.entity.Customer;
import com.exception.CustomerFoundException;
import com.exception.CustomerNotFoundException;
import com.repository.CustomerRepo;
import com.service.CustomerService;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CustomerController {
	
	@Autowired
	CustomerService custService;
	@Autowired
	CustomerRepo custRepo;
	
	@PostMapping("/customers")
	public ResponseEntity<?> insertCustomer(@Valid @RequestBody Customer cust) throws CustomerFoundException{
		Customer customer = custService.addCustomer(cust);
		return new ResponseEntity<Customer>(customer,HttpStatus.CREATED);
	}
	
	@GetMapping("/customers")
	public ResponseEntity<?> retreiveAllCustomers() throws CustomerNotFoundException{
		List<CustDto> clist= custService.getAllCustomers();
		if(clist.isEmpty()) {
			return new ResponseEntity<String>("No Customers found",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<CustDto>>(clist,HttpStatus.OK);
	}
	
	@Transactional
	@GetMapping("/customers/{custId}")
	public ResponseEntity<?> getCustomerById(@PathVariable long custId) throws CustomerNotFoundException{
		Customer cust = custService.findCustomerById(custId);
		Hibernate.initialize(cust); 
		return new ResponseEntity<Customer>(cust,HttpStatus.OK);
	}
	
	@PutMapping("/customers/{custId}")
	public ResponseEntity<?> updateCustById(@PathVariable("custId") long custId, @RequestBody Customer cust) throws CustomerNotFoundException{
		Customer customer = custService.updateCustomerById(custId, cust);
		return new ResponseEntity<Customer>(customer, HttpStatus.OK);
	}
	
	@DeleteMapping("/customers/{custId}")
	public ResponseEntity<?> removeCustomer(@PathVariable("custId") long custId) throws CustomerNotFoundException{
		Customer cust= custService.findCustomerById(custId);
		custService.deleteCustomer(custId);
		return ResponseEntity.ok("{\"message\": \"Deleted account Successfully\"}");
	}
	
	@PatchMapping("/customers/{name}/{custId}")
	public ResponseEntity<?> updateCustName(@PathVariable String name,@PathVariable("custId") long custId) throws CustomerNotFoundException{
		Customer cust = custService.findCustomerById(custId);
		cust=custService.updateCustomerName(custId, name);
		return new ResponseEntity<Customer>(cust, HttpStatus.OK);
		
	}
	
	@PatchMapping("/customers/{custId}")
	public ResponseEntity<?> updateCustAddress(@PathVariable("custId") long custId, @RequestBody Address addr) throws CustomerNotFoundException{
		Customer cust = custService.findCustomerById(custId);
		cust=custService.updateCustomerAddr(custId, addr);
		return new ResponseEntity<Customer>(cust, HttpStatus.OK);
		
	}
	
	@GetMapping("/customer/{custId}")
	public ResponseEntity<?> getCustomerDtoById(@PathVariable long custId) throws CustomerNotFoundException{
		CustDto cust = custService.getCustDtoById(custId);
		return new ResponseEntity<CustDto>(cust,HttpStatus.OK);
	}
	
	@PutMapping("/customer/{custId}")
	public ResponseEntity<?> updateCustomerDtoById(@PathVariable long custId, @RequestBody CustDto customer) throws CustomerNotFoundException{
		CustDto cust=custService.updateCustDtoById(custId, customer);
		return new ResponseEntity<CustDto>(cust, HttpStatus.OK);
	}

	@GetMapping("/customers/email")
	public ResponseEntity<?> getByEmail(@RequestParam String email){
		Customer cust=custService.findByEmail(email);
		if(cust==null) {
			return new ResponseEntity<String>("Cannot find Customer",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Customer>(cust, HttpStatus.OK);
	}
	
}
