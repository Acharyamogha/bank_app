package com.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dto.AccountDto;
import com.entity.Account;
import com.entity.Customer;
import com.entity.Transaction;
import com.exception.AccountNotFoundException;
import com.service.AccountService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class AccountController {
	
	@Autowired
	AccountService accService;
	
	@PostMapping("/accounts")
	public ResponseEntity<?> insertAccount(@RequestBody Account acc){
		Account account= accService.addAccount(acc);
		if(account==null) {
			return new ResponseEntity<String>("Cannot insert account", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Account>(account,HttpStatus.CREATED);
	}
	
	@GetMapping("/accounts/{accId}")
	public ResponseEntity<?> getAccountById(@PathVariable long accId) throws AccountNotFoundException{
		AccountDto account= accService.getAccountDetailsById(accId);
		return new ResponseEntity<AccountDto>(account,HttpStatus.OK);
	}
	
	@GetMapping("/accounts")
	public ResponseEntity<?> getAllAccounts(){
		List<AccountDto> alist = accService.getAllAccounts();
		if(alist==null) {
			return new ResponseEntity<String>("Cannot retrieve account details", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<AccountDto>>(alist,HttpStatus.OK);
	}
	
	@GetMapping("/accounts/customer/{custId}")
	public ResponseEntity<?> getAllAccountsByCustId(@PathVariable long custId){
		List<AccountDto> alist = accService.findByCustId(custId);
		if(alist.isEmpty()) {
			return new ResponseEntity<String>("Cannot retrieve account details", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<AccountDto>>(alist,HttpStatus.OK);
	}
	
	@PutMapping("/accounts")
	public ResponseEntity<?> updateAccount(@RequestBody Account acc) throws AccountNotFoundException{
		Account account= accService.updateAccount(acc);
		return new ResponseEntity<Account>(account,HttpStatus.OK);
	}
	
	@DeleteMapping("/accounts/{accId}")
	public ResponseEntity<?> removeAccount(@PathVariable long accId) throws AccountNotFoundException{
		accService.deleteAccount(accId);
		return ResponseEntity.ok("{\"message\": \"Deleted account Successfully\"}");
	}
	
	@GetMapping("/accounts/{accId}/balance")
	public ResponseEntity<?> getAccountBalanceById(@PathVariable long accId)throws AccountNotFoundException{
		double balance=accService.getAccountBalanceById(accId);
		return new ResponseEntity<Double>(balance,HttpStatus.OK);
	}
	
	@GetMapping("/accounts/exists/{accId}")
	public ResponseEntity<?> verifyAccountExists(@PathVariable long accId){
		Map<String, String> response = new HashMap<>();
		if(accService.verifyAccountExists(accId)) {
			response.put("message", "Account with ID " + accId +" exists");
			return new ResponseEntity<>(response,HttpStatus.OK);
		}
		response.put("message", "Account with ID " + accId +" does not exist");
		return new ResponseEntity<>(response,HttpStatus.OK);
	}
	
	@PatchMapping("/accounts/{accId}/freeze")
	public ResponseEntity<?> freezeAccount(@PathVariable long accId) throws AccountNotFoundException{
		int i=accService.freezeAccount(accId);
		Map<String, String> response = new HashMap<>();
		if(i>0) {
			response.put("message", "Account with ID " + accId +" is frozen ");
			return new ResponseEntity<>(response,HttpStatus.OK);
		}
		else {
			response.put("message", "Account cannot be frozen");
			return new ResponseEntity<>(response,HttpStatus.OK);
		}
	}
	
	@PatchMapping("/accounts/{accId}/unfreeze")
	public ResponseEntity<?> unFreezeAccount(@PathVariable long accId) throws AccountNotFoundException{
		int i=accService.unFreezeAccount(accId);
			Map<String, String> response = new HashMap<>();
		if(i>0) {
			response.put("message", "Account with ID " + accId +" is unfrozen ");
			return new ResponseEntity<>(response,HttpStatus.OK);
		}
		else {
			response.put("message", "Account cannot be unfrozen");
			return new ResponseEntity<>(response,HttpStatus.OK);
		}
	}
	
	@GetMapping("/accounts/{accId}/holder")
	public ResponseEntity<?> getCustomerDetails(@PathVariable long accId) throws AccountNotFoundException{
		Customer cust = accService.getCustomerDetails(accId);
		return new ResponseEntity<Customer>(cust, HttpStatus.OK);
	}
	

@GetMapping("/accounts/{accId}/statement")
public ResponseEntity<?> getTransactionsByAccountIdAndDateRange(@PathVariable Long accId,@RequestParam String startDate, @RequestParam String endDate) throws AccountNotFoundException{

	LocalDate start = LocalDate.parse(startDate, DateTimeFormatter.ISO_LOCAL_DATE);
	LocalDate end = LocalDate.parse(endDate, DateTimeFormatter.ISO_LOCAL_DATE);

	LocalDateTime startDateTime = start.atStartOfDay();
	LocalDateTime endDateTime = end.atTime(23, 59, 59);
	List<Transaction> tlist = accService.findTransactionsByAccIdAndDateRange(accId, startDateTime, endDateTime);
	if(tlist==null) {
		return new ResponseEntity<String>("No transactions exist", HttpStatus.INTERNAL_SERVER_ERROR);
	}
	return new ResponseEntity<List<Transaction>>(tlist, HttpStatus.OK);
	}
}
